package edu.ucla.cs.cs144;

public class FieldName {
	public static final String ItemName = "ItemName";	// java.lang.String
	public static final String Category = "Category";	// java.lang.String
	public static final String SellerId = "SellerId";	// java.lang.String
	public static final String BuyPrice = "BuyPrice";	// java.lang.Double
	public static final String BidderId = "BidderId";	// java.lang.String
	public static final String EndTime = "EndTime";		// java.util.Date
	public static final String Description = "Description";	// java.lang.String
}
